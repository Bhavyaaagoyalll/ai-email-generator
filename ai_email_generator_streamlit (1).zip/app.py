import os
import streamlit as st

st.set_page_config(
    page_title="AI Email Generator",
    page_icon="✉️",
    layout="centered"
)

st.markdown("""
<style>
    .main {max-width: 850px; padding-top: 2rem;}
    .hero {
        padding: 1.5rem;
        border-radius: 16px;
        background: linear-gradient(120deg, #172554, #1d4ed8);
        color: white;
        margin-bottom: 1.5rem;
    }
    .hero h1 {color: white; margin-bottom: .3rem;}
    .hero p {color: #dbeafe; margin-bottom: 0;}
    div.stButton > button {
        width: 100%;
        border-radius: 10px;
        min-height: 2.8rem;
        font-weight: 600;
    }
</style>
""", unsafe_allow_html=True)

st.markdown("""
<div class="hero">
  <h1>✉️ AI Email Generator</h1>
  <p>Create clear, professional emails and customer responses in seconds.</p>
</div>
""", unsafe_allow_html=True)

with st.form("email_form"):
    response_type = st.selectbox(
        "What would you like to create?",
        ["Business Email", "Customer Response"]
    )
    purpose = st.text_input(
        "Purpose",
        placeholder="e.g. Request leave, follow up on a meeting"
    )
    recipient = st.text_input(
        "Recipient",
        placeholder="e.g. Professor, Manager, Customer"
    )
    tone = st.selectbox("Tone", ["Formal", "Friendly", "Polite"])
    key_points = st.text_area(
        "Key points to include",
        placeholder="Write the main details you want the email to cover...",
        height=140
    )
    extra = st.text_input(
        "Optional details",
        placeholder="e.g. Keep it under 150 words"
    )
    submitted = st.form_submit_button("✨ Generate email")

def template_email(kind, purpose, recipient, tone, points):
    if tone == "Friendly":
        greeting, closing = f"Hello {recipient},", "Best wishes,"
    elif tone == "Polite":
        greeting, closing = f"Respected {recipient},", "Thank you,"
    else:
        greeting, closing = f"Dear {recipient},", "Regards,"

    if kind == "Customer Response":
        opening = f"Thank you for contacting us regarding {purpose.lower()}."
        signoff = "Customer Support Team"
    else:
        opening = f"I am writing to {purpose.lower()}."
        signoff = "Your Name"

    return f"{greeting}\n\n{opening}\n\n{points}\n\n{closing}\n{signoff}"

def generate_with_openai(kind, purpose, recipient, tone, points, extra):
    try:
        from openai import OpenAI
        api_key = st.secrets.get("OPENAI_API_KEY", os.getenv("OPENAI_API_KEY", ""))
        if not api_key:
            return None, "No OpenAI API key configured."
        client = OpenAI(api_key=api_key)
        prompt = f"""
Write a polished {kind.lower()}.
Recipient: {recipient}
Purpose: {purpose}
Tone: {tone}
Key points: {points}
Additional instructions: {extra or "None"}
Use a suitable subject line when appropriate. Do not invent facts.
Return only the email draft.
"""
        response = client.responses.create(
            model="gpt-4.1-mini",
            input=prompt
        )
        return response.output_text.strip(), None
    except Exception as e:
        return None, f"AI generation unavailable: {e}"

if submitted:
    if not all([purpose.strip(), recipient.strip(), key_points.strip()]):
        st.error("Please fill in Purpose, Recipient and Key points.")
    else:
        with st.spinner("Creating your email..."):
            draft, error = generate_with_openai(
                response_type, purpose, recipient, tone, key_points, extra
            )
            if draft:
                st.session_state["draft"] = draft
                st.session_state["mode"] = "AI-generated"
            else:
                st.session_state["draft"] = template_email(
                    response_type, purpose, recipient, tone, key_points
                )
                st.session_state["mode"] = "Basic template"
                st.session_state["notice"] = error

if "draft" in st.session_state:
    st.divider()
    st.subheader("Your generated email")
    if st.session_state.get("mode") == "AI-generated":
        st.success("Generated using AI")
    else:
        st.info("Generated using a basic template. Add an OpenAI API key to enable AI-generated wording.")
        if st.session_state.get("notice"):
            with st.expander("Setup information"):
                st.caption(st.session_state["notice"])
    st.text_area("Email draft", value=st.session_state["draft"], height=260)
    st.download_button(
        "⬇️ Download email as TXT",
        data=st.session_state["draft"],
        file_name="generated_email.txt",
        mime="text/plain"
    )

with st.expander("How to enable actual AI generation"):
    st.markdown("""
1. Create an OpenAI API key in your OpenAI developer account.
2. In Streamlit, add a secret named `OPENAI_API_KEY`.
3. Paste your API key as its value and redeploy the app.

Keep your API key private. Do not paste it into the public source code.
""")

st.caption("Student practical project • Email drafts should be reviewed before sending.")
