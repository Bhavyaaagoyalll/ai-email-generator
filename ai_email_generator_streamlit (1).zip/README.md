# AI Email Generator

A beginner-friendly Streamlit project for a Prompt Engineering practical.

## Run on your computer

1. Install Python.
2. Open a terminal in this folder.
3. Run: `pip install -r requirements.txt`
4. Run: `streamlit run app.py`

The app works in basic template mode without an API key. To enable actual AI-generated wording,
set `OPENAI_API_KEY` as an environment variable or add it to Streamlit secrets.

## Deploy as a website

1. Upload `app.py` and `requirements.txt` to a GitHub repository.
2. Open https://share.streamlit.io/
3. Connect your GitHub account and select the repository and `app.py`.
4. In app settings, add the secret `OPENAI_API_KEY` if you want actual AI generation.
5. Deploy.

Do not publish your API key in GitHub.
